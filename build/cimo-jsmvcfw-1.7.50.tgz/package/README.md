# Npm_jsMvcFw
Npm package, javascript mvc framework. Light, fast and secure.
Writed with native Typescript code and no dependencies are used.

The framework is a platform designed to simplify the development of dynamic user interfaces and modern web applications.
It provides a clear structure and integrated tools to create reusable components, manage application state, and update the UI reactively, reducing code complexity and improving maintainability.

## Pack
1. npm run build
2. Copy the file "/build/package_name-x.x.x.tgz" in the project root folder.
3. In the "package.json" file insert: "@cimo/package_name": "file:package_name-x.x.x.tgz"

## Publish

1. npm run build
2. npm login --auth-type=legacy
3. npm publish --auth-type=legacy --access public

## Installation
1. Link for npm package -> https://www.npmjs.com/package/@cimo/jsmvcfw

## Reset
1. Delete this from the root:
    - build
    - dist
    - node_modules

2. Follow the "Installation" instructions.

## Example
1. In this repository are present the app example with all wiki and example:

    https://github.com/cimo/App_jsMvcFw
